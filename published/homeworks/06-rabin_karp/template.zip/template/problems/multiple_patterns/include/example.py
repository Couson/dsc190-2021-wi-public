>>> multiple_rabin_karp("this is a test", ["this", "is"])
[[0], [2 5]]
