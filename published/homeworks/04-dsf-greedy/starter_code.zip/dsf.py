"""Starter code for DisjointSetForest.

This file contains starter code for DisjointSetForest. Note that you may need to change 
already-existing classes/methods/functions in this file!

"""

class DisjointSetForest:
    
    def __init__(self):
        self._parent = []
        self._rank = []
    
    def make_set(self):
        """Create a new singleton set.
        
        Returns
        -------
        int
            The id of the element that was just inserted.
            
        """
        # get the new element's "id"
        x = len(self._parent)
        self._parent.append(None)
        self._rank.append(0)
        return x
    
    def find_set(self, x):
        """Find the representative of the element.
        
        Parameters
        ----------
        x : int
            The element to look for.
            
        Returns
        -------
        int
            The representative of the set containing x.
            
        Raises
        ----
        ValueError
            If x is not in the collection.
        
        """
        try:
            parent = self._parent[x]
        except IndexError:
            raise ValueError(f'{x} is not in the collection.')
            
        if self._parent[x] is None:
            return x
        else:
            root = self.find_set(self._parent[x])
            self._parent[x] = root
            return root
    
    def union(self, x, y):
        """Union the sets containing x and y, in-place.
        
        Parameters
        ----------
        x, y : int
            The elements whose sets should be unioned.
            
        Raises
        ------
        ValueError
            If x or y are not in the collection.
            
        """
        x_rep = self.find_set(x)
        y_rep = self.find_set(y)
        
        if x_rep == y_rep:
            return
        
        if self._rank[x_rep] > self._rank[y_rep]:
            self._parent[y_rep] = x_rep
        else:
            self._parent[x_rep] = y_rep
            if self._rank[x_rep] == self._rank[y_rep]:
                self._rank[y_rep] += 1
                
    def size_of_set(self, x):
        """The size of the set containing x.
        
        Parameters
        ----------
        x : int
            The element whose set will be sized.
            
        Returns
        -------
        int
            The size of the set containing x.
            
        Raises
        ------
        ValueError
            If x is not in the collection.
            
        """
        ...
